# First install  composer 
# Run command to create Laravel project "composer create-project laravel/laravel {folder name}"
# open .env file and setup the database configuration 

# add route in  web.php
# create new controller directory  and extent with controller
# Manage request with ajax 
# I used blade template for view the tree

#Process to view the tree First i passed the directory  which i need to generate the tree
in  first step i have iterate all  folder and in second iterate the files only
#append all  the folders and directory  in  ul and li once click on  name next file and folder will  be open.  
